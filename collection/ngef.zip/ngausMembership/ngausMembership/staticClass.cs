using System;
using System.Collections.Generic;
using System.Text;

namespace Contensive.Addons.ngausMembership
{
    static class statics
    {
        public static string cr = "\n\t";
        public static string cr2 = "\n\t\t";
        public static string cr3 = "\n\t\t\t";
        //
        public const string rnSrcFormId = "srcFormId";
        public const string rnDstFormId = "dstFormId";
        public const string rnButton = "button";
        public const string rnAppId = "appId";
        //
        public const string buttonBack = "Back";
        public const string buttonNext = "Next";
        public const string buttonEdit = "Edit";
        public const string buttonMakePayment = "Make Payment";
        //
        public const int formIdSignup = 1;
        public const int formIdConfirm = 2;
        public const int formIdPay = 3;
        public const int formIdThanks = 4;
        //
        public const string cnApps = "Ngaus Join Applications";
        public const string cnMemberships = "Ngaus Membership Levels";
        //
    }
}
